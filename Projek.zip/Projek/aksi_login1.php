<?php
session_start();

// Koneksi database
$koneksi = mysqli_connect(
    "127.0.0.1",
    "root",
    "root",
    "db_perpustakaan"
);

if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Pastikan form dikirim dengan POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: login1.php");
    exit;
}

// Ambil username dan password
$email = trim($_POST['email'] ?? '');
$password = $_POST['pass'] ?? '';

if ($email === '' || $password === '') {
    header("Location: login1.php?error=empty");
    exit;
}

// Cari pengguna berdasarkan username
$sql = "SELECT
            email.*,
            COALESCE(anggota.nama, admin.nama) AS nama,
            email.kelas
        FROM tb_user
        LEFT JOIN tb_user ON users.id = email.user_id
        WHERE users.email = ?
        LIMIT 1";

$stmt = mysqli_prepare($koneksi, $sql);

if (!$stmt) {
    die("Query gagal: " . mysqli_error($koneksi));
}

mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);

// Periksa password
$password_valid = false;

if ($user) {
    $password_db = $user['pass'];

    // Mendukung password hash dan password teks biasa
    if (password_verify($password, $password_db)) {
        $password_valid = true;
    } elseif (hash_equals((string) $password_db, (string) $password)) {
        $password_valid = true;
    }
}

if ($user && $password_valid) {

    session_regenerate_id(true);

    $_SESSION['id'] = $user['id'];
    $_SESSION['id_user'] = $user['id'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['role'] = strtolower($user['role']);
    $_SESSION['nama'] = $user['nama'] ?? $user['email'];
    $_SESSION['kelas'] = $user['kelas'] ?? null;
    $_SESSION['login'] = true;

    mysqli_stmt_close($stmt);
    mysqli_close($koneksi);

    header("Location: dashboard1.php");
    exit;

} else {
    mysqli_stmt_close($stmt);
    mysqli_close($koneksi);

    header("Location: login1.php?error=1");
    exit;
}
