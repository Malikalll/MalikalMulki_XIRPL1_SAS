<?php
require_once 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: registrasi1.php");
    exit;
}

// Ambil data form
$nama = trim($_POST['nama'] ?? '');
$kelas = trim($_POST['kelas'] ?? '');
$jenis_kelamin = $_POST['jenis_kelamin'] ?? '';
$email = trim($_POST['email'] ?? '');
$pass = $_POST['pass'] ?? '';

// Validasi input
if (
    $nama === '' ||
    $kelas === '' ||
    $email === '' ||
    $pass === '' ||
    !in_array($jenis_kelamin, ['L', 'P'], true)
) {
    echo "<script>
            alert('Semua data wajib diisi!');
            window.location.href='registrasi1.php';
          </script>";
    exit;
}

// Enkripsi password
$pass = password_hash($pass, PASSWORD_DEFAULT);

// Mulai transaksi
mysqli_begin_transaction($koneksi);

try {

    // Cek username
    $cek_email = mysqli_prepare(
        $koneksi,
        "SELECT id FROM tb_user WHERE email = ?"
    );

    mysqli_stmt_bind_param($cek_email, "s", $email);
    mysqli_stmt_execute($cek_email);
    mysqli_stmt_store_result($cek_email);

    if (mysqli_stmt_num_rows($cek_email) > 0) {
        throw new Exception("Email sudah digunakan!");
    }

    // Simpan akun users
    $sql_user = "INSERT INTO tb_user
                 (id_user, email, pass, role, jenis_kelamin, nama, kelas, created_at)
                 VALUES ('', ?, ?, 'anggota', ?, ?, ?, NOW())";

    $stmt_user = mysqli_prepare($koneksi, $sql_user);

    mysqli_stmt_bind_param(
        $stmt_user,
        "ss",
        $email,
        $pass,
        $jenis_kelamin,
        $nama,
        $kelas
    );

    if (!mysqli_stmt_execute($stmt_user)) {
        throw new Exception("Gagal membuat akun!");
    }

    // Ambil ID user
    $user_id = mysqli_insert_id($koneksi);

    // Simpan transaksi
    mysqli_commit($koneksi);

    echo "<script>
            alert('Registrasi berhasil! Silakan login.');
            window.location.href='login1.php';
          </script>";

} catch (Exception $e) {

    mysqli_rollback($koneksi);

    $pesan = json_encode(
        $e->getMessage(),
        JSON_HEX_TAG | JSON_HEX_APOS |
        JSON_HEX_QUOT | JSON_HEX_AMP
    );

    echo "<script>
            alert($pesan);
            window.location.href='registrasi1.php';
          </script>";
}

mysqli_close($koneksi);
?>
