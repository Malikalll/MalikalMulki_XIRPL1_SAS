<?php
$username = "root";
$password = "root";
$hostname = "127.0.0.1";
$data = "db_perpustakaan";

$koneksi = mysqli_connect("127.0.0.1","root","root","db_perpustakaan");

if ($koneksi) {
    //echo "koneksi berhasil";
}
else{
    echo "koneksi gagal";
}
?>