<?php
require_once 'koneksi.php';
?>

<!doctype html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Registrasi Anggota - PERPUSTAKAAN</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <style>
        body {
            background: #f8f9fc;
            font-family: Arial, sans-serif;
            color: #334155;
        }

        .form-container {
            max-width: 650px;
            margin: 40px auto;
            padding: 0 16px;
        }

        .form-card {
            background: #fff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,0.04);
        }

        .form-header {
            padding: 22px 24px;
            border-bottom: 1px solid #e5e7eb;
            border-left: 4px solid #6366f1;
        }

        .form-header h2 {
            margin: 0;
            font-size: 23px;
            font-weight: 700;
            color: #1e293b;
        }

        .form-header p {
            margin: 6px 0 0;
            font-size: 14px;
            color: #64748b;
        }

        .form-content {
            padding: 24px;
        }

        .section-title {
            font-size: 17px;
            font-weight: 700;
            color: #334155;
            padding-bottom: 10px;
            margin: 8px 0 20px;
            border-bottom: 1px solid #e5e7eb;
        }

        .form-label {
            font-size: 14px;
            font-weight: 600;
            color: #475569;
        }

        .form-control {
            border-color: #dbe1e8;
            border-radius: 7px;
            padding: 10px 12px;
            font-size: 14px;
        }

        .form-control:focus {
            border-color: #818cf8;
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.12);
        }

        .form-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-top: 24px;
        }

        .btn {
            border-radius: 6px;
            padding: 9px 14px;
            font-size: 13px;
        }

        @media (max-width: 576px) {
            .form-container {
                margin: 20px auto;
                padding: 0 10px;
            }

            .form-content {
                padding: 18px;
            }
        }
    </style>
</head>

<body>

<div class="form-container">

    <div class="form-card">

        <div class="form-header">
            <h2>
                <i class="bi bi-person-plus-fill"></i>
                Registrasi Anggota
            </h2>

            <p>
                Daftarkan akun dan lengkapi data profil anggota.
            </p>
        </div>

        <div class="form-content">

            <form action="aksi_registrasi1.php" method="POST">

                <h5 class="section-title">
                    <i class="bi bi-person-vcard"></i>
                    Data Profil Anggota
                </h5>

                <div class="mb-3">
                    <label for="nama" class="form-label">Nama Lengkap</label>

                    <input
                        type="text"
                        class="form-control"
                        id="nama"
                        name="nama"
                        placeholder="Masukkan nama lengkap"
                        required
                    >
                </div>

                <div class="mb-3">
                    <label for="kelas" class="form-label">Kelas</label>

                    <input
                        type="text"
                        class="form-control"
                        id="kelas"
                        name="kelas"
                        placeholder="Contoh: XI-RPL-1"
                        required
                    >
                </div>

  <div class="mb-4">
                    <label class="form-label d-block">
                        Jenis Kelamin
                    </label>

                    <div class="form-check">
                        <input
                            class="form-check-input"
                            type="radio"
                            name="jenis_kelamin"
                            id="L"
                            value="L"
                            required
                        >

                        <label class="form-check-label" for="L">
                            Laki-laki
                        </label>
                    </div>

                    <div class="form-check">
                        <input
                            class="form-check-input"
                            type="radio"
                            name="jenis_kelamin"
                            id="P"
                            value="P"
                        >

                        <label class="form-check-label" for="P">
                            Perempuan
                        </label>
                    </div>
                      </div>

                <h5 class="section-title">
                    <i class="bi bi-shield-lock"></i>
                    Data Akun Anggota
                </h5>

                <div class="mb-3">
                    <label for="email" class="form-label">
                        Email
                    </label>

                    <input
                        type="text"
                        class="form-control"
                        id="email"
                        name="email"
                        placeholder="Buat username"
                        autocomplete="email"
                        required
                    >
                </div>

                <div class="mb-3">
                    <label for="pass" class="form-label">
                        Password
                    </label>

                    <input
                        type="pass"
                        class="form-control"
                        id="pass"
                        name="pass"
                        placeholder="Buat password"
                        autocomplete="new-password"
                        required
                    >
                </div>

                <div class="form-actions">

                    <button
                        type="submit"
                        class="btn btn-primary"
                    >
                        <i class="bi bi-person-check"></i>
                        Daftar Sekarang
                    </button>

                    <a href="login1.php" class="btn btn-secondary">
                        <i class="bi bi-box-arrow-in-left"></i>
                        Kembali ke Login
                    </a>

                </div>

            </form>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
